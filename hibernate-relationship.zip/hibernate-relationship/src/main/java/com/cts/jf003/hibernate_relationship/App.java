package com.cts.jf003.hibernate_relationship;

import java.text.ParseException;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.cts.jf003.hibernate_relationship.entity.Customer;
import com.cts.jf003.hibernate_relationship.entity.Department;
import com.cts.jf003.hibernate_relationship.entity.Employee;
import com.cts.jf003.hibernate_relationship.entity.Order;
import com.cts.jf003.hibernate_relationship.entity.Product;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) throws ParseException
    {
        System.out.println( "Hello World!" );
        //object representation of my configuration file	(hibernate.cfg.xml)
        Configuration config=new Configuration();
        config.configure("hibernate.cfg.xml");
        config.addAnnotatedClass(Department.class);
        config.addAnnotatedClass(Employee.class);
        config.addAnnotatedClass(Customer.class);
        config.addAnnotatedClass(Product.class);
        config.addAnnotatedClass(Order.class);
        Session session = config.buildSessionFactory()
        .openSession();
//        Customer c1=new Customer(null, "Ravi", "Shankar", "9898989898");
//        Product p1=new Product("Penci", "Used to write", 10.2, "2020-10-01", "2022-10-01");
        Customer c1=session.get(Customer.class, 13L);
        Product p1=session.get(Product.class, 14L);
//        Order order=new Order(null, new Date(), p1, c1, 12);
//        Transaction tran = session.beginTransaction();
//        session.save(order);
//        tran.commit();
        List<Order> orders = c1.getOrders();
        for(Order o : orders)
        	System.out.println(o.getId());
        System.out.println("Done");
        //find the department so that we get managed entity of department
//        Department dept=null;
//        dept=session.get(Department.class, 2L);
//        List<Employee> employees = dept.getEmployees();
//        for(Employee e : employees)
//        	System.out.println(e);
//        Date doj=new Date();
//        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
//        doj=sdf.parse("2010-12-12");
//        Employee employee=new Employee("Ram", "Kumar", doj, dept);
//        Transaction tran = session.beginTransaction();
//        Serializable id = session.save(employee);
//        tran.commit();
//        session.close();
//        System.out.println("A new employee is added in department "+dept.getId()+". Note emp id:"+id);
    }
}
