package com.cts.jf003.hibernate_relationship.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "OrderDetails")
public class Order {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	private Date orderDate;
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="product_id",referencedColumnName="id")
	private Product product;
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="customer_id",referencedColumnName="id")
	private Customer customer;
	private Integer quantity;
	public Order() {
		
	}
	public Order(Long id, Date orderDate, Product product, Customer customer, Integer quantity) {
		super();
		this.id = id;
		this.orderDate = orderDate;
		this.product = product;
		this.customer = customer;
		this.quantity = quantity;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Date getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	
	
}
