package com.cts.jf003.hibernate_relationship.entity;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Product {
//	productId, name, description, price, manufactureDate, expiryDate
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	private String name;
	private String description;
	private Double price;
	private Date manufactureDate;
	private Date expiryDate;
	
	public Product() {}

	public Product(Long id, String name, String description, Double price, Date manufactureDate, Date expiryDate) {
		super();
		this.id = id;
		this.name = name;
		this.description = description;
		this.price = price;
		this.manufactureDate = manufactureDate;
		this.expiryDate = expiryDate;
	}
	public Product(String name, String description, Double price, Date manufactureDate, Date expiryDate) {
		this.name = name;
		this.description = description;
		this.price = price;
		this.manufactureDate = manufactureDate;
		this.expiryDate = expiryDate;
	}
	public Product(String name, String description, Double price, String manufactureDate, String expiryDate) throws ParseException {
		this.name = name;
		this.description = description;
		this.price = price;
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		this.manufactureDate = sdf.parse(manufactureDate);
		this.expiryDate = sdf.parse(expiryDate);
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public Date getManufactureDate() {
		return manufactureDate;
	}

	public void setManufactureDate(Date manufactureDate) {
		this.manufactureDate = manufactureDate;
	}

	public void setManufactureDate(String manufactureDate) throws ParseException {
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		this.manufactureDate = sdf.parse(manufactureDate);
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}	
	public void setExpiryDate(String expiryDate) throws ParseException {
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		this.expiryDate = sdf.parse(expiryDate);
	}

	@Override
	public String toString() {
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		return "Product [id=" + id + ", name=" + name + ", description=" + description + ", price=" + price
				+ ", manufactureDate=" + sdf.format(manufactureDate) + ", expiryDate=" + sdf.format(expiryDate) + "]";
	}	
	
}
